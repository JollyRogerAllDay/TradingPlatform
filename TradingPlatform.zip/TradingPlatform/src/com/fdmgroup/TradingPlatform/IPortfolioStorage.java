package com.fdmgroup.TradingPlatform;

public class IPortfolioStorage {

}
