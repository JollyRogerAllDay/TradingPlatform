package com.fdmgroup.TradingPlatform;

public enum Permissions {
	BROKER,SHAREHOLDER,SYSADMIN,BROKER_SHAREHOLDER,GUEST
}