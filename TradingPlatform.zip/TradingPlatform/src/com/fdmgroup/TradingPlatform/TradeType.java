package com.fdmgroup.TradingPlatform;

public enum TradeType {
	BUY,SELL
}