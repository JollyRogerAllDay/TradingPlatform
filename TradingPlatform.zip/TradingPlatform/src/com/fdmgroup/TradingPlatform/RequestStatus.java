package com.fdmgroup.TradingPlatform;

public enum RequestStatus {
	OUTSTANDING, IN_PROGRESS, COMPLETED
}