package com.fdmgroup.TradingPlatform;

public enum UserRequestType {
	RESET_PASSWORD, REPORT_BUG, CHANGE_PERMISSION
}
