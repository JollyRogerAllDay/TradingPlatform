package com.fdmgroup.TradingPlatform;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import com.fdmgroup.TradingPlatform.Permissions;
import com.fdmgroup.TradingPlatform.RequestStatus;
import com.fdmgroup.TradingPlatform.Shareholder;
import com.fdmgroup.TradingPlatform.SystemAdmin;
import com.fdmgroup.TradingPlatform.User;
import com.fdmgroup.TradingPlatform.UserRequest;
import com.fdmgroup.TradingPlatform.UserRequestList;
import com.fdmgroup.TradingPlatform.UserRequestType;

public class RequestListTest {

	private UserRequestList requests;
	private User sh;
	private SystemAdmin admin;
	private UserRequest request;
	
	@Before
	public void init()
	{

	}
	


}
